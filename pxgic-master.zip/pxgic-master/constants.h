#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QString>

const QString DB_DIRECTORY = "Security.db";

#endif // CONSTANTS_H
