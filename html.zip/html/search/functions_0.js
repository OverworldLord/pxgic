var searchData=
[
  ['addcustomer',['addCustomer',['../class_data_base_manager.html#aef5a03ada397e8014d4988031299871b',1,'DataBaseManager']]],
  ['addpurchase',['addPurchase',['../class_data_base_manager.html#ae1d3d51beedea76a803a08ee4d930d97',1,'DataBaseManager']]],
  ['adminmenu',['AdminMenu',['../class_admin_menu.html#a0c3a25e9cb87d5ace6a172abc7cff1b1',1,'AdminMenu']]],
  ['advancedmaths',['AdvancedMaths',['../class_advanced_maths.html#aaa8dda5c8272ba10927ca427458b6ff7',1,'AdvancedMaths']]]
];
