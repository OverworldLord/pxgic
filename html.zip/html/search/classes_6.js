var searchData=
[
  ['pamphlet',['pamphlet',['../class_ui_1_1pamphlet.html',1,'Ui::pamphlet'],['../classpamphlet.html',1,'pamphlet']]]
];
