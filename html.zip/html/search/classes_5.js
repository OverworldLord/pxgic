var searchData=
[
  ['mainwindow',['MainWindow',['../class_ui_1_1_main_window.html',1,'Ui::MainWindow'],['../class_main_window.html',1,'MainWindow']]],
  ['makepurchase',['MakePurchase',['../class_ui_1_1_make_purchase.html',1,'Ui::MakePurchase'],['../class_make_purchase.html',1,'MakePurchase']]],
  ['moreinformation',['MoreInformation',['../class_ui_1_1_more_information.html',1,'Ui::MoreInformation'],['../class_more_information.html',1,'MoreInformation']]]
];
