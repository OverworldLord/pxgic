var searchData=
[
  ['pxgic',['pxgic',['../md__c_1__users_agerard0__desktop_pxgic-testbranch__r_e_a_d_m_e.html',1,'']]],
  ['pamphlet',['pamphlet',['../class_ui_1_1pamphlet.html',1,'Ui::pamphlet'],['../classpamphlet.html',1,'pamphlet'],['../classpamphlet.html#a8b6f8b9df24742110317005ac23471f4',1,'pamphlet::pamphlet()']]]
];
