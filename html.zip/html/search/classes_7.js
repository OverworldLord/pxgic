var searchData=
[
  ['saleslisting',['salesListing',['../class_ui_1_1sales_listing.html',1,'Ui::salesListing'],['../classsales_listing.html',1,'salesListing']]],
  ['simplemaths',['SimpleMaths',['../class_simple_maths.html',1,'']]]
];
