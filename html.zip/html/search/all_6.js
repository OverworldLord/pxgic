var searchData=
[
  ['name',['name',['../class_login_window.html#ad2dbf161b23c40d20720edc52a5baf46',1,'LoginWindow']]]
];
