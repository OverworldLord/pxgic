var searchData=
[
  ['mainwindow',['MainWindow',['../class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db',1,'MainWindow']]],
  ['makepurchase',['MakePurchase',['../class_make_purchase.html#a38330e2622b2b11164a64c0be8f0a7d5',1,'MakePurchase']]],
  ['moreinformation',['MoreInformation',['../class_more_information.html#afc3a81e2a3d7713eea4e212a8654871a',1,'MoreInformation']]]
];
