var searchData=
[
  ['databasemanager',['DataBaseManager',['../class_data_base_manager.html',1,'']]],
  ['delcustomer',['DelCustomer',['../class_ui_1_1_del_customer.html',1,'Ui::DelCustomer'],['../class_del_customer.html',1,'DelCustomer']]],
  ['delcustomers',['DelCustomers',['../class_del_customers.html',1,'']]]
];
