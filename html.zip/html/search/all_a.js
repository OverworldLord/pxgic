var searchData=
[
  ['retrievetestimonials',['retrieveTestimonials',['../class_data_base_manager.html#aa32113e132a74f4360cbd89a5881bb03',1,'DataBaseManager']]],
  ['returndb',['returnDB',['../class_data_base_manager.html#a4123f9414307197bc5563a3b4c5ed90b',1,'DataBaseManager']]]
];
