var searchData=
[
  ['testimonyexists',['testimonyExists',['../class_data_base_manager.html#aac8365e3f1dc1649668fe27e360bbb06',1,'DataBaseManager']]],
  ['testuser',['testUser',['../class_data_base_manager.html#ab847a03b34827157b6ec58360ed90e16',1,'DataBaseManager']]]
];
