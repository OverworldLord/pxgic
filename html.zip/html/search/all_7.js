var searchData=
[
  ['opendb',['openDB',['../class_data_base_manager.html#a2e4c7fcaecbf8f0644e73b0e0905f796',1,'DataBaseManager']]],
  ['operator_2b',['operator+',['../class_advanced_maths.html#a97d7ac2f687d600226b978dcc1ba6eb3',1,'AdvancedMaths::operator+()'],['../class_simple_maths.html#a47b6a3a70adead459da4a748a09ecd7e',1,'SimpleMaths::operator+()']]],
  ['operator_2b_2b',['operator++',['../class_advanced_maths.html#ab5422a84ad73f94ab721607564d06334',1,'AdvancedMaths']]]
];
