var searchData=
[
  ['pamphlet',['pamphlet',['../classpamphlet.html#a8b6f8b9df24742110317005ac23471f4',1,'pamphlet']]]
];
