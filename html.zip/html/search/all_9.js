var searchData=
[
  ['qryexec',['qryExec',['../class_data_base_manager.html#ad5b1ec51c81d04130be314251ad29654',1,'DataBaseManager']]]
];
