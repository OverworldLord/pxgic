var searchData=
[
  ['databasemanager',['DataBaseManager',['../class_data_base_manager.html',1,'DataBaseManager'],['../class_data_base_manager.html#a876dd05c6424d0efb99d95a2c584a804',1,'DataBaseManager::DataBaseManager()']]],
  ['delcustomer',['DelCustomer',['../class_ui_1_1_del_customer.html',1,'Ui::DelCustomer'],['../class_del_customer.html',1,'DelCustomer'],['../class_del_customer.html#a338d877f8adbb4f29dfd4bcaf879ab8c',1,'DelCustomer::DelCustomer()']]],
  ['delcustomers',['DelCustomers',['../class_del_customers.html',1,'']]],
  ['deletecustomer',['deleteCustomer',['../class_data_base_manager.html#a32ffcd1a585a95e56a6d8212cdd9f1c8',1,'DataBaseManager']]]
];
